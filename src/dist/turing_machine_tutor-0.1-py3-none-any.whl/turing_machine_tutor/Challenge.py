class Challenge:
    def __init__(self, turing_machine_description, function_that_accepts_the_language_of_tm, edge_cases_list):
        self.description=turing_machine_description
        self.function=function_that_accepts_the_language_of_tm
        self.edge_cases=edge_cases_list
